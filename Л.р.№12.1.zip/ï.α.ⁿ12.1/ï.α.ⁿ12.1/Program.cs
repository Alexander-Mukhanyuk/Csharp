﻿using System;

namespace Л.р._12._1
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = 10;//объявление переменных
            Random rand = new Random();
            string Message = "Ошибка-IndexOutOfRangeException";
            int[] Array; //объявление массива
            Array = new int[10]; //описание массива
            Console.WriteLine("Массив:");//вывод текста
            for (int k = 0; k < n; k++) //объявление цикла
            {
                Array[k] = rand.Next(-10, n);  //заполнение массива рандомными числами
                Console.Write(Array[k]+" ");//вывод элементов массива
            }
            Console.WriteLine();
                try//контрлируемый блок
                {
                Console.WriteLine(Array[n]); //попытка считывание элемента
                }
                catch (IndexOutOfRangeException)//блок обработка исключения
                {
                    Console.WriteLine(Message);
                }
            int i = 10 * n;//описание переменных
            int j = 5 + n;
            while (j != -10)//объявление цикла
            {
                try//контрлируемый блок
                {
                    Console.Write((i % j) + " ");// попытка вывод остатка после деления
                }
                catch (DivideByZeroException)//блок обработка исключения
                {
                    Console.WriteLine("Делить на ноль нельзя!");
                }
                i += 3;
                j += -1;
            }
        }
    }
}
